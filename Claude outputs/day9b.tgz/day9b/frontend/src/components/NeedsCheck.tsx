import { Box, Paper, Typography } from "@mui/material";
import type { Entry } from "../api/types";
import { LOW_CONFIDENCE, formatMoney } from "../lib/format";
import { useI18n } from "../i18n";
import { useTokens } from "../theme";
import { Icon } from "./Icon";

// Entries the AI was unsure about (and nobody has corrected yet), so they are easy to find and fix.
export function NeedsCheck({ entries, onOpen }: { entries: Entry[]; onOpen: (id: string) => void }) {
  const { t, lang } = useI18n();
  const c = useTokens();
  const flagged = entries.filter((e) => e.confidence < LOW_CONFIDENCE && !e.user_corrected);
  if (flagged.length === 0) return null;
  return (
    <Paper variant="outlined" component="section" aria-label={t("check.title")} sx={{ p: 4, borderRadius: 3 }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Typography sx={{ fontWeight: 600 }}>{t("check.title")}</Typography>
        <Box component="span" sx={{ display: "inline-flex", alignItems: "center", gap: 1, fontSize: 12, fontWeight: 600, color: c.warn }}>
          <Icon name="alert" size={14} />
          {flagged.length}
        </Box>
      </Box>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>{t("check.help")}</Typography>
      <Box component="ul" sx={{ listStyle: "none", m: 0, mt: 2, p: 0 }}>
        {flagged.slice(0, 5).map((e) => (
          <li key={e.id}>
            <Box
              component="button"
              type="button"
              onClick={() => onOpen(e.id)}
              sx={{
                all: "unset", boxSizing: "border-box", width: "100%", minHeight: 44, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 3,
                cursor: "pointer", borderRadius: 1.5, "&:focus-visible": { outline: `2px solid ${c.focus}`, outlineOffset: 2 },
              }}
            >
              <Typography noWrap sx={{ fontSize: 14 }}>{e.merchant ?? e.note ?? t("entry.noMerchant")}</Typography>
              <Typography sx={{ fontSize: 14, fontWeight: 500, fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>
                {formatMoney(e.amount, e.currency, lang)}
              </Typography>
            </Box>
          </li>
        ))}
      </Box>
    </Paper>
  );
}
